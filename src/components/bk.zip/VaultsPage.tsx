import { useEffect, useMemo, useState } from 'react';
import { VaultDetailPanel } from './VaultDetailPanel';
import { VaultList } from './VaultList';
import {
  fetchVaultDepositors,
  fetchVaultDetail,
  fetchVaultPositions,
  fetchVaultTrades,
  fetchVaults,
} from '../services/vaults';
import type {
  VaultDepositor,
  VaultDetail,
  VaultPosition,
  VaultSummary,
  VaultTrade,
} from '../types/vault';

export function VaultsPage() {
  const [vaults, setVaults] = useState<VaultSummary[]>([]);
  const [selected, setSelected] = useState<VaultSummary | null>(null);
  const [detail, setDetail] = useState<VaultDetail | null>(null);
  const [trades, setTrades] = useState<VaultTrade[]>([]);
  const [positions, setPositions] = useState<VaultPosition[]>([]);
  const [depositors, setDepositors] = useState<VaultDepositor[]>([]);
  const [loading, setLoading] = useState(true);
  const [detailLoading, setDetailLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedAddress = selected?.vault_address ?? null;

  const loadVaults = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetchVaults({ limit: 200 });
      const items = response.items ?? [];
      setVaults(items);
      if (items.length > 0) {
        setSelected((prev) => prev ?? items[0]);
      } else {
        setSelected(null);
        setDetail(null);
        setTrades([]);
        setPositions([]);
        setDepositors([]);
      }
    } catch (err) {
      setError((err as Error).message);
      setVaults([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVaults();
  }, []);

  useEffect(() => {
    const loadDetail = async () => {
      if (!selectedAddress) return;
      setDetailLoading(true);
      try {
        const [vaultDetail, tradesData, positionsData, depositorsData] = await Promise.all([
          fetchVaultDetail(selectedAddress),
          fetchVaultTrades(selectedAddress, 30),
          fetchVaultPositions(selectedAddress),
          fetchVaultDepositors(selectedAddress),
        ]);
        setDetail(vaultDetail);
        setTrades(tradesData);
        setPositions(positionsData);
        setDepositors(depositorsData);
      } catch (err) {
        setError((err as Error).message);
        setDetail(null);
        setTrades([]);
        setPositions([]);
        setDepositors([]);
      } finally {
        setDetailLoading(false);
      }
    };

    loadDetail();
  }, [selectedAddress]);

  const headerText = useMemo(() => {
    if (loading) return '正在加载 Vault 数据...';
    if (error) return `加载失败: ${error}`;
    return `已加载 ${vaults.length} 个 Vault`;
  }, [loading, error, vaults.length]);

  return (
    <div className="min-h-screen text-white p-4 md:p-6" style={{ backgroundColor: '#1A0B2E' }}>
      <div className="max-w-[1600px] mx-auto space-y-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="text-2xl font-semibold">Vault 数据面板</div>
            <div className="text-sm text-white/60 mt-1">{headerText}</div>
          </div>
          <button
            type="button"
            onClick={loadVaults}
            className="inline-flex items-center justify-center rounded-lg border border-white/20 px-4 py-2 text-sm text-white/80 hover:text-white hover:border-white/40 transition"
            disabled={loading}
          >
            刷新数据
          </button>
        </div>

        <div className="grid gap-6 lg:grid-cols-[minmax(0,360px)_minmax(0,1fr)]">
          <div className="space-y-4">
            <VaultList items={vaults} selectedAddress={selectedAddress} onSelect={setSelected} />
          </div>
          <div className="space-y-4">
            {detailLoading ? (
              <div className="rounded-xl border border-white/10 bg-white/5 px-4 py-6 text-white/70">
                正在加载详情...
              </div>
            ) : (
              <VaultDetailPanel
                vault={detail}
                trades={trades}
                positions={positions}
                depositors={depositors}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
