import { cn } from './ui/utils';
import { Card } from './ui/card';
import type { VaultSummary } from '../types/vault';

const formatNumber = (value?: number | null, options?: Intl.NumberFormatOptions) => {
  if (value === null || value === undefined || Number.isNaN(value)) return '--';
  return new Intl.NumberFormat('en-US', options).format(value);
};

const formatPercent = (value?: number | null) => {
  if (value === null || value === undefined || Number.isNaN(value)) return '--';
  return `${(value * 100).toFixed(2)}%`;
};

const shortenAddress = (address?: string | null) => {
  if (!address) return '--';
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
};

interface VaultListProps {
  items: VaultSummary[];
  selectedAddress?: string | null;
  onSelect: (vault: VaultSummary) => void;
}

export function VaultList({ items, selectedAddress, onSelect }: VaultListProps) {
  return (
    <Card className="bg-white/10 border-white/15 text-white">
      <div className="px-4 py-3 border-b border-white/10 text-sm uppercase tracking-wide text-white/70">
        Vault 列表
      </div>
      <div className="divide-y divide-white/10">
        {items.map((vault) => (
          <button
            key={vault.vault_address}
            type="button"
            onClick={() => onSelect(vault)}
            className={cn(
              'w-full text-left px-4 py-3 transition hover:bg-white/5',
              selectedAddress === vault.vault_address && 'bg-white/10'
            )}
          >
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <div className="text-base font-semibold">
                    {vault.name || '未命名 Vault'}
                  </div>
                  <div className="text-xs text-white/60">{shortenAddress(vault.vault_address)}</div>
                </div>
                <div className="text-xs rounded-full border border-white/20 px-2 py-0.5 text-white/70">
                  {vault.status || 'unknown'}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs text-white/70">
                <div>
                  <div className="text-white/50">TVL(USDC)</div>
                  <div className="text-white">
                    {formatNumber(vault.tvl_usdc, { maximumFractionDigits: 0 })}
                  </div>
                </div>
                <div>
                  <div className="text-white/50">年化回报</div>
                  <div className="text-white">{formatPercent(vault.annualized_return)}</div>
                </div>
                <div>
                  <div className="text-white/50">Sharpe</div>
                  <div className="text-white">
                    {formatNumber(vault.sharpe, { maximumFractionDigits: 2 })}
                  </div>
                </div>
                <div>
                  <div className="text-white/50">最大回撤</div>
                  <div className="text-white">{formatPercent(vault.max_drawdown)}</div>
                </div>
              </div>
            </div>
          </button>
        ))}
        {items.length === 0 && (
          <div className="px-4 py-8 text-center text-white/60 text-sm">暂无可用 Vault 数据</div>
        )}
      </div>
    </Card>
  );
}
