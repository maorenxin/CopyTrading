import { Card } from './ui/card';
import type { VaultDetail, VaultDepositor, VaultPosition, VaultTrade } from '../types/vault';

const formatNumber = (value?: number | null, options?: Intl.NumberFormatOptions) => {
  if (value === null || value === undefined || Number.isNaN(value)) return '--';
  return new Intl.NumberFormat('en-US', options).format(value);
};

const formatPercent = (value?: number | null) => {
  if (value === null || value === undefined || Number.isNaN(value)) return '--';
  return `${(value * 100).toFixed(2)}%`;
};

const formatTime = (value?: string | null) => {
  if (!value) return '--';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString();
};

const shortenAddress = (address?: string | null) => {
  if (!address) return '--';
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
};

interface VaultDetailPanelProps {
  vault?: VaultDetail | null;
  trades: VaultTrade[];
  positions: VaultPosition[];
  depositors: VaultDepositor[];
}

export function VaultDetailPanel({
  vault,
  trades,
  positions,
  depositors,
}: VaultDetailPanelProps) {
  if (!vault) {
    return (
      <Card className="bg-white/10 border-white/15 text-white h-full">
        <div className="px-4 py-6 text-center text-white/60 text-sm">请选择一个 Vault 查看详情</div>
      </Card>
    );
  }

  return (
    <Card className="bg-white/10 border-white/15 text-white">
      <div className="px-4 py-4 border-b border-white/10">
        <div className="text-lg font-semibold">{vault.name || '未命名 Vault'}</div>
        <div className="text-xs text-white/60 mt-1">{shortenAddress(vault.vault_address)}</div>
        {vault.description && (
          <div className="text-sm text-white/70 mt-2 line-clamp-2">{vault.description}</div>
        )}
      </div>
      <div className="px-4 py-4 grid gap-4 sm:grid-cols-2">
        <div>
          <div className="text-xs text-white/50">状态</div>
          <div className="text-sm">{vault.status || 'unknown'}</div>
        </div>
        <div>
          <div className="text-xs text-white/50">最近交易时间</div>
          <div className="text-sm">{formatTime(vault.last_trade_at)}</div>
        </div>
        <div>
          <div className="text-xs text-white/50">TVL(USDC)</div>
          <div className="text-sm">{formatNumber(vault.tvl_usdc, { maximumFractionDigits: 0 })}</div>
        </div>
        <div>
          <div className="text-xs text-white/50">累计回报</div>
          <div className="text-sm">{formatPercent(vault.all_time_return)}</div>
        </div>
        <div>
          <div className="text-xs text-white/50">年化回报</div>
          <div className="text-sm">{formatPercent(vault.annualized_return)}</div>
        </div>
        <div>
          <div className="text-xs text-white/50">Sharpe</div>
          <div className="text-sm">{formatNumber(vault.sharpe, { maximumFractionDigits: 2 })}</div>
        </div>
        <div>
          <div className="text-xs text-white/50">最大回撤</div>
          <div className="text-sm">{formatPercent(vault.max_drawdown)}</div>
        </div>
        <div>
          <div className="text-xs text-white/50">同步批次</div>
          <div className="text-xs break-all text-white/70">{vault.last_sync_run_id || '--'}</div>
        </div>
      </div>
      <div className="px-4 pb-4 grid gap-3 sm:grid-cols-3 text-xs text-white/70">
        <div className="rounded-lg border border-white/10 px-3 py-2">
          <div className="text-white/50">交易记录</div>
          <div className="text-sm text-white">{trades.length}</div>
        </div>
        <div className="rounded-lg border border-white/10 px-3 py-2">
          <div className="text-white/50">持仓</div>
          <div className="text-sm text-white">{positions.length}</div>
        </div>
        <div className="rounded-lg border border-white/10 px-3 py-2">
          <div className="text-white/50">存款人</div>
          <div className="text-sm text-white">{depositors.length}</div>
        </div>
      </div>
      <div className="px-4 pb-5">
        <div className="text-xs uppercase tracking-wide text-white/60 mb-2">最新交易</div>
        <div className="space-y-2">
          {trades.slice(0, 5).map((trade) => (
            <div
              key={trade.tx_hash}
              className="rounded-lg border border-white/10 px-3 py-2 text-xs text-white/70"
            >
              <div className="flex items-center justify-between">
                <span>{trade.side || 'N/A'}</span>
                <span>{formatTime(trade.timestamp ?? trade.utc_time)}</span>
              </div>
              <div className="flex items-center justify-between mt-1">
                <span>Price: {formatNumber(trade.price, { maximumFractionDigits: 4 })}</span>
                <span>Size: {formatNumber(trade.size, { maximumFractionDigits: 4 })}</span>
              </div>
            </div>
          ))}
          {trades.length === 0 && (
            <div className="text-sm text-white/60">暂无交易数据</div>
          )}
        </div>
      </div>
    </Card>
  );
}
